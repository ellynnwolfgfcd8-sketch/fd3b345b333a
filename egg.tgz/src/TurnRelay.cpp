// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Allocate relay\n", stdout);
  return lionss_run_workload("TurnRelay");
}
