// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Split-map-reduce\n", stdout);
  return lionss_run_workload("rayon_splitmix");
}
