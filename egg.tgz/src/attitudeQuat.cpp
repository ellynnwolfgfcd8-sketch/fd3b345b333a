// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Integrate quaternion\n", stdout);
  return lionss_run_workload("attitudeQuat");
}
