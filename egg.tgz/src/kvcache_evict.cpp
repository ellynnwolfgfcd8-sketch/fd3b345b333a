// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Evict KV entries\n", stdout);
  return lionss_run_workload("kvcache_evict");
}
