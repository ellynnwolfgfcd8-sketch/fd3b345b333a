// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Mix vermilion tone"); }
int main(){
  announce();
  return lionss_run_workload("vermilion");
}
