// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Step Nesterov SGD"); }
int main(){
  announce();
  return lionss_run_workload("sgd-nesterov");
}
