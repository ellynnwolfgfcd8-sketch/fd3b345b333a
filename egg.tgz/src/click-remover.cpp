// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Remove clicks"); }
int main(){
  announce();
  return lionss_run_workload("click-remover");
}
